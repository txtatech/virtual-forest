def generate_dark_tower_adventure(ai):
    # Generate the Dark Tower Adventure for the AI

    ai.narrative.append("You begin the Dark Tower Adventure.")
    return ai.generate_new_adventure("Dark Tower")
