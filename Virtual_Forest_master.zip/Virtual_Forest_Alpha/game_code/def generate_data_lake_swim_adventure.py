def generate_data_lake_swim_adventure(ai):
    # Generate the Data Lake Swim Adventure for the AI

    ai.narrative.append("You begin the Data Lake Swim Adventure.")
    return ai.generate_new_adventure("Data Lake Swim")
